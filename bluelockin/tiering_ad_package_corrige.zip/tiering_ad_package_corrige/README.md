# Package Tiering AD corrige

Ce package contient une version simplifiee du script.

## Changements

- Aucun envoi mail.
- Creation uniquement de comptes admin.
- Suppression de l'utilisation directe de colonnes avec accents dans le script.
- Mots de passe generes par le script.
- Mots de passe avec lettres et chiffres uniquement.
- Export des mots de passe avec le nom du compte admin.

## Test

```powershell
.\Implement-TieringModelAD.ps1 -WhatIf
```

## Execution

```powershell
.\Implement-TieringModelAD.ps1
```

## Export

Les mots de passe sont exportes dans :

```text
.\exports\MotsDePasse_Comptes_Admin.csv
```

La matrice serveur est exportee dans :

```text
.\exports\Matrice_Acces_Serveurs.csv
```
