<#
.SYNOPSIS
    Implementation simple d'un modele Tiering Active Directory depuis deux fichiers CSV.

.DESCRIPTION
    Ce script cree uniquement des comptes admin.
    Il cree les OU, les groupes AD par niveau T0/T1/T2, les groupes d'acces serveur,
    puis ajoute les comptes admin dans les bons groupes.

    Aucun envoi mail.
    Les mots de passe sont generes par le script et exportes dans un fichier CSV.
    Les mots de passe contiennent uniquement des lettres et des chiffres.

.FICHIERS CSV ATTENDUS
    Comptes_Admin_Tiering.csv
    Serveurs_Tiering.csv

.EXEMPLES
    .\Implement-TieringModelAD.ps1 -WhatIf
    .\Implement-TieringModelAD.ps1
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$AccountsCsv = ".\Comptes_Admin_Tiering.csv",
    [string]$ServersCsv = ".\Serveurs_Tiering.csv",
    [string]$OutputFolder = ".\exports",

    [string]$DomainDN = "DC=corp,DC=local",
    [string]$GroupRootOU = "OU=Groups,DC=corp,DC=local",
    [string]$AdminRootOU = "OU=Admins,DC=corp,DC=local",
    [string]$ServerRootOU = "OU=Servers,DC=corp,DC=local",

    [string]$DefaultUpnSuffix = "corp.local",
    [switch]$CreateGpoSkeleton
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "[+] $Message" -ForegroundColor Cyan
}

function Ensure-Module {
    param([string]$Name)

    if (-not (Get-Module -ListAvailable -Name $Name)) {
        throw "Module PowerShell manquant: $Name"
    }

    Import-Module $Name -ErrorAction Stop
}

function Get-CsvValue {
    param(
        [Parameter(Mandatory = $true)]$Row,
        [Parameter(Mandatory = $true)][string[]]$Names
    )

    foreach ($name in $Names) {
        if ($Row.PSObject.Properties.Name -contains $name) {
            return ([string]$Row.PSObject.Properties[$name].Value).Trim()
        }
    }

    return ""
}

function Remove-TextAccent {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ""
    }

    $normalized = $Text.Normalize([Text.NormalizationForm]::FormD)
    $builder = New-Object System.Text.StringBuilder

    foreach ($char in $normalized.ToCharArray()) {
        $category = [Globalization.CharUnicodeInfo]::GetUnicodeCategory($char)
        if ($category -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$builder.Append($char)
        }
    }

    return $builder.ToString().Normalize([Text.NormalizationForm]::FormC)
}

function ConvertTo-SafeName {
    param([string]$Value)

    $valueNoAccent = Remove-TextAccent -Text $Value
    $safe = $valueNoAccent.ToUpper() -replace "[^A-Z0-9]", "_"
    $safe = $safe -replace "_+", "_"
    $safe = $safe.Trim("_")

    if ([string]::IsNullOrWhiteSpace($safe)) {
        return "UNKNOWN"
    }

    return $safe
}

function ConvertTo-SafeSamAccountName {
    param([string]$Value)

    $valueNoAccent = Remove-TextAccent -Text $Value
    $safe = $valueNoAccent.ToLower() -replace "[^a-z0-9]", ""

    if ([string]::IsNullOrWhiteSpace($safe)) {
        return "admunknown"
    }

    if ($safe -notlike "adm*") {
        $safe = "adm$safe"
    }

    if ($safe.Length -gt 20) {
        $safe = $safe.Substring(0, 20)
    }

    return $safe
}

function Ensure-OU {
    param([Parameter(Mandatory = $true)][string]$DistinguishedName)

    try {
        Get-ADOrganizationalUnit -Identity $DistinguishedName -ErrorAction Stop | Out-Null
        return
    }
    catch {
        # Creation si l'OU n'existe pas
    }

    $parts = $DistinguishedName -split ","
    $dcParts = $parts | Where-Object { $_ -like "DC=*" }
    $ouParts = $parts | Where-Object { $_ -like "OU=*" }

    [array]::Reverse($ouParts)

    $parent = ($dcParts -join ",")

    foreach ($ouPart in $ouParts) {
        $ouName = $ouPart -replace "^OU=", ""
        $currentDn = "OU=$ouName,$parent"

        try {
            Get-ADOrganizationalUnit -Identity $currentDn -ErrorAction Stop | Out-Null
        }
        catch {
            if ($PSCmdlet.ShouldProcess($currentDn, "Create OU")) {
                New-ADOrganizationalUnit `
                    -Name $ouName `
                    -Path $parent `
                    -ProtectedFromAccidentalDeletion $true | Out-Null
            }
        }

        $parent = $currentDn
    }
}

function Ensure-ADGroup {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Path,
        [string]$Description = ""
    )

    Ensure-OU -DistinguishedName $Path

    $existingGroup = Get-ADGroup -LDAPFilter "(sAMAccountName=$Name)" -ErrorAction SilentlyContinue
    if ($existingGroup) {
        return $existingGroup
    }

    if ($PSCmdlet.ShouldProcess($Name, "Create AD group")) {
        New-ADGroup `
            -Name $Name `
            -SamAccountName $Name `
            -GroupCategory Security `
            -GroupScope Global `
            -Path $Path `
            -Description $Description | Out-Null
    }

    return Get-ADGroup -LDAPFilter "(sAMAccountName=$Name)"
}

function New-RandomPassword {
    param([int]$Length = 20)

    $lower = "abcdefghjkmnpqrstuvwxyz"
    $upper = "ABCDEFGHJKMNPQRSTUVWXYZ"
    $digits = "23456789"
    $allChars = ($lower + $upper + $digits).ToCharArray()

    $chars = New-Object System.Collections.Generic.List[char]
    $chars.Add($lower[(Get-Random -Maximum $lower.Length)])
    $chars.Add($upper[(Get-Random -Maximum $upper.Length)])
    $chars.Add($digits[(Get-Random -Maximum $digits.Length)])

    while ($chars.Count -lt $Length) {
        $chars.Add($allChars[(Get-Random -Maximum $allChars.Length)])
    }

    return (-join ($chars | Sort-Object { Get-Random }))
}

function Ensure-AdminPasswordPolicy {
    param(
        [string[]]$AdminGroupNames,
        [string]$PolicyName = "PSO_Admin_Tiering_180J"
    )

    $pso = Get-ADFineGrainedPasswordPolicy -Filter "Name -eq '$PolicyName'" -ErrorAction SilentlyContinue

    if (-not $pso) {
        if ($PSCmdlet.ShouldProcess($PolicyName, "Create password policy")) {
            New-ADFineGrainedPasswordPolicy `
                -Name $PolicyName `
                -Precedence 10 `
                -ComplexityEnabled $true `
                -ReversibleEncryptionEnabled $false `
                -MinPasswordLength 14 `
                -PasswordHistoryCount 24 `
                -MaxPasswordAge (New-TimeSpan -Days 180) `
                -MinPasswordAge (New-TimeSpan -Days 1) `
                -LockoutThreshold 5 `
                -LockoutDuration (New-TimeSpan -Minutes 15) `
                -LockoutObservationWindow (New-TimeSpan -Minutes 15) | Out-Null
        }
    }

    foreach ($groupName in $AdminGroupNames) {
        $group = Get-ADGroup -Identity $groupName -ErrorAction SilentlyContinue

        if ($group) {
            try {
                if ($PSCmdlet.ShouldProcess($groupName, "Apply password policy")) {
                    Add-ADFineGrainedPasswordPolicySubject `
                        -Identity $PolicyName `
                        -Subjects $groupName `
                        -ErrorAction Stop
                }
            }
            catch {
                if ($_.Exception.Message -notmatch "already|existe|deja") {
                    Write-Warning "Impossible d'appliquer la PSO sur $groupName : $($_.Exception.Message)"
                }
            }
        }
    }
}

function Ensure-GpoSkeleton {
    param([array]$Servers)

    Ensure-Module -Name GroupPolicy

    foreach ($tier in @("T0", "T1", "T2")) {
        $gpoName = "GPO_Tiering_${tier}_LocalAdmins"
        $targetOu = "OU=$tier,$ServerRootOU"

        Ensure-OU -DistinguishedName $targetOu

        $existingGpo = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
        if (-not $existingGpo) {
            if ($PSCmdlet.ShouldProcess($gpoName, "Create GPO")) {
                New-GPO `
                    -Name $gpoName `
                    -Comment "GPO skeleton for local admins on $tier servers" | Out-Null
            }
        }

        try {
            if ($PSCmdlet.ShouldProcess($targetOu, "Link GPO $gpoName")) {
                New-GPLink `
                    -Name $gpoName `
                    -Target $targetOu `
                    -LinkEnabled Yes `
                    -ErrorAction Stop | Out-Null
            }
        }
        catch {
            if ($_.Exception.Message -notmatch "already|existe|deja") {
                Write-Warning "Lien GPO non cree sur $targetOu : $($_.Exception.Message)"
            }
        }
    }
}

Ensure-Module -Name ActiveDirectory

if (-not (Test-Path $AccountsCsv)) {
    throw "Fichier introuvable: $AccountsCsv"
}

if (-not (Test-Path $ServersCsv)) {
    throw "Fichier introuvable: $ServersCsv"
}

New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null

Write-Step "Import des fichiers CSV"
$accounts = Import-Csv -Path $AccountsCsv -Delimiter ";"
$servers = Import-Csv -Path $ServersCsv -Delimiter ";"

Write-Step "Creation des OU principales"
Ensure-OU -DistinguishedName $AdminRootOU
Ensure-OU -DistinguishedName $GroupRootOU
Ensure-OU -DistinguishedName $ServerRootOU

foreach ($tier in @("T0", "T1", "T2")) {
    Ensure-OU -DistinguishedName "OU=$tier,$AdminRootOU"
    Ensure-OU -DistinguishedName "OU=$tier,$ServerRootOU"
}

Write-Step "Creation des groupes admin par tier"
$adminTierGroupNames = @()

foreach ($tier in @("T0", "T1", "T2")) {
    $tierAdminGroup = "GG_${tier}_Admins"
    Ensure-ADGroup `
        -Name $tierAdminGroup `
        -Path $GroupRootOU `
        -Description "Admin accounts for tier $tier" | Out-Null

    $adminTierGroupNames += $tierAdminGroup
}

Write-Step "Creation des groupes d'acces serveurs"
$serverAccessMatrix = @()

foreach ($server in $servers) {
    $serverName = Get-CsvValue -Row $server -Names @("NomServeur", "Nom serveur", "Serveur", "Server")
    $tier = Get-CsvValue -Row $server -Names @("NiveauTiering", "Niveau Tiering", "Tier")
    $serverRole = Get-CsvValue -Row $server -Names @("RoleServeur", "Role serveur", "Role")
    $serverOu = Get-CsvValue -Row $server -Names @("OUCible", "OU cible", "OU")

    if ([string]::IsNullOrWhiteSpace($serverName)) {
        continue
    }

    if ([string]::IsNullOrWhiteSpace($tier)) {
        $tier = "T2"
    }

    if ($tier -notin @("T0", "T1", "T2")) {
        $tier = "T2"
    }

    if ([string]::IsNullOrWhiteSpace($serverOu)) {
        $serverOu = "OU=$tier,$ServerRootOU"
    }

    Ensure-OU -DistinguishedName $serverOu

    $safeServerName = ConvertTo-SafeName -Value $serverName
    $localAdminGroup = "GLA_${safeServerName}_Administrators"
    $tierAdminGroup = "GG_${tier}_Admins"

    Ensure-ADGroup `
        -Name $localAdminGroup `
        -Path $GroupRootOU `
        -Description "Local admin access group for server $serverName" | Out-Null

    if ($PSCmdlet.ShouldProcess("$tierAdminGroup to $localAdminGroup", "Add group member")) {
        Add-ADGroupMember `
            -Identity $localAdminGroup `
            -Members $tierAdminGroup `
            -ErrorAction SilentlyContinue
    }

    $serverAccessMatrix += [pscustomobject]@{
        NomServeur = $serverName
        NiveauTiering = $tier
        RoleServeur = $serverRole
        OUCibleServeur = $serverOu
        GroupeLocalAdminAD = $localAdminGroup
        GroupeAdminAutorise = $tierAdminGroup
    }
}

Write-Step "Creation des comptes admin"
$generatedPasswords = @()

foreach ($account in $accounts) {
    $nom = Get-CsvValue -Row $account -Names @("Nom", "NOM")
    $prenom = Get-CsvValue -Row $account -Names @("Prenom", "Prenom", "FirstName")
    $rawSam = Get-CsvValue -Row $account -Names @("CompteAdmin", "sAMAccountName", "Login", "SamAccountName")
    $rawUpn = Get-CsvValue -Row $account -Names @("UPN", "UPN / Email", "Email", "Mail")
    $tier = Get-CsvValue -Row $account -Names @("NiveauTiering", "Niveau Tiering", "Tier")
    $equipe = Get-CsvValue -Row $account -Names @("Equipe", "Team")
    $service = Get-CsvValue -Row $account -Names @("Service")
    $fonction = Get-CsvValue -Row $account -Names @("Fonction", "Poste")
    $manager = Get-CsvValue -Row $account -Names @("Manager")

    if ([string]::IsNullOrWhiteSpace($tier)) {
        $tier = "T2"
    }

    if ($tier -notin @("T0", "T1", "T2")) {
        $tier = "T2"
    }

    if ([string]::IsNullOrWhiteSpace($rawSam)) {
        $baseSam = "$($prenom.Substring(0, [Math]::Min(1, $prenom.Length)))$nom"
        $sam = ConvertTo-SafeSamAccountName -Value $baseSam
    }
    else {
        $sam = ConvertTo-SafeSamAccountName -Value $rawSam
    }

    if ([string]::IsNullOrWhiteSpace($sam)) {
        Write-Warning "Ligne ignoree: compte admin vide"
        continue
    }

    if ([string]::IsNullOrWhiteSpace($rawUpn)) {
        $upn = "$sam@$DefaultUpnSuffix"
    }
    else {
        $upnDomain = $DefaultUpnSuffix
        if ($rawUpn -like "*@*") {
            $upnDomain = ($rawUpn -split "@", 2)[1]
        }
        $upn = "$sam@$upnDomain"
    }

    $displayName = "$prenom $nom".Trim()
    if ([string]::IsNullOrWhiteSpace($displayName)) {
        $displayName = $sam
    }

    $targetOu = "OU=$tier,$AdminRootOU"
    $groupName = "GG_${tier}_Admins"

    $plainPassword = New-RandomPassword -Length 20
    $securePassword = ConvertTo-SecureString $plainPassword -AsPlainText -Force

    $existingUser = Get-ADUser -LDAPFilter "(sAMAccountName=$sam)" -ErrorAction SilentlyContinue

    if (-not $existingUser) {
        if ($PSCmdlet.ShouldProcess($sam, "Create AD admin account")) {
            New-ADUser `
                -Name $displayName `
                -GivenName $prenom `
                -Surname $nom `
                -DisplayName $displayName `
                -SamAccountName $sam `
                -UserPrincipalName $upn `
                -EmailAddress $upn `
                -Path $targetOu `
                -AccountPassword $securePassword `
                -Enabled $true `
                -ChangePasswordAtLogon $false `
                -PasswordNeverExpires $false `
                -Description "Admin account tier $tier" | Out-Null
        }
    }
    else {
        Write-Host "Compte existant: $sam"

        if ($PSCmdlet.ShouldProcess($sam, "Update AD admin account")) {
            Set-ADUser `
                -Identity $sam `
                -DisplayName $displayName `
                -EmailAddress $upn `
                -UserPrincipalName $upn `
                -Description "Admin account tier $tier"
        }
    }

    if ($PSCmdlet.ShouldProcess("$sam to $groupName", "Add admin account to tier group")) {
        Add-ADGroupMember `
            -Identity $groupName `
            -Members $sam `
            -ErrorAction SilentlyContinue
    }

    $generatedPasswords += [pscustomobject]@{
        CompteAdmin = $sam
        UPN = $upn
        Nom = $nom
        Prenom = $prenom
        DisplayName = $displayName
        Equipe = $equipe
        Service = $service
        Fonction = $fonction
        Manager = $manager
        NiveauTiering = $tier
        MotDePasseInitial = $plainPassword
        ExpirationMotDePasseJours = 180
    }
}

Write-Step "Application de la politique mot de passe 180 jours"
Ensure-AdminPasswordPolicy -AdminGroupNames $adminTierGroupNames

Write-Step "Export des resultats"
$passwordFile = Join-Path $OutputFolder "MotsDePasse_Comptes_Admin.csv"
$matrixFile = Join-Path $OutputFolder "Matrice_Acces_Serveurs.csv"

$generatedPasswords | Export-Csv -Path $passwordFile -Delimiter ";" -NoTypeInformation -Encoding UTF8
$serverAccessMatrix | Export-Csv -Path $matrixFile -Delimiter ";" -NoTypeInformation -Encoding UTF8

if ($CreateGpoSkeleton) {
    Write-Step "Creation des squelettes GPO"
    Ensure-GpoSkeleton -Servers $servers
}

Write-Host ""
Write-Host "Termine." -ForegroundColor Green
Write-Host "Dossier export: $OutputFolder" -ForegroundColor Green
Write-Host "Fichier mots de passe: $passwordFile" -ForegroundColor Yellow
Write-Host "Fichier matrice serveurs: $matrixFile" -ForegroundColor Yellow
Write-Host ""
Write-Host "Action GPO restante:" -ForegroundColor Yellow
Write-Host "Ajouter les groupes GLA_<SERVEUR>_Administrators dans le groupe Administrators local des serveurs concernes."
