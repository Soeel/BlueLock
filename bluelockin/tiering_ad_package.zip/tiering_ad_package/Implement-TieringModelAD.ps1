<#
.SYNOPSIS
    Implémente un modèle de Tiering Active Directory à partir de fichiers CSV générés depuis le tableau Excel.

.DESCRIPTION
    Ce script crée :
      - Les OU cibles des comptes et serveurs
      - Les groupes AD par niveau de Tiering
      - Les comptes utilisateurs/admins
      - Les affectations groupes par niveau T0/T1/T2
      - Une PSO / Fine-Grained Password Policy de 180 jours pour les comptes admin
      - Un export CSV des mots de passe initiaux utilisés
      - Une matrice d'accès serveurs/groupes pour appliquer ensuite les GPO

    IMPORTANT :
      - Aucune logique d'envoi de mot de passe par mail n'est présente dans ce script.
      - Les mots de passe initiaux sont uniquement exportés dans un fichier CSV de démonstration.
      - En production, privilégier un coffre-fort type CyberArk, KeePass entreprise, LAPS/Windows LAPS, PAM ou remise via canal séparé.

.PREREQUIS
    - PowerShell 5.1+ sur un poste d'administration / contrôleur de domaine
    - RSAT Active Directory : module ActiveDirectory
    - RSAT Group Policy : module GroupPolicy si tu veux créer les GPO de structure
    - Droits suffisants dans l'AD
    - Les CSV doivent être en UTF-8 avec séparateur ;

.EXEMPLE
    .\Implement-TieringModelAD.ps1 -WhatIf

.EXEMPLE
    .\Implement-TieringModelAD.ps1 -CreateGpoSkeleton
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$AccountsCsv = ".\Comptes_Tiering.csv",
    [string]$ServersCsv = ".\Serveurs_Tiering.csv",
    [string]$PasswordCsv = ".\MotsDePasse_Initiaux_DEMO.csv",
    [string]$OutputFolder = ".\exports",

    [string]$DomainDN = "DC=corp,DC=local",
    [string]$GroupRootOU = "OU=Groups,DC=corp,DC=local",
    [string]$ServerRootOU = "OU=Servers,DC=corp,DC=local",

    [switch]$CreateGpoSkeleton
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "[+] $Message" -ForegroundColor Cyan
}

function Ensure-Module {
    param([string]$Name)
    if (-not (Get-Module -ListAvailable -Name $Name)) {
        throw "Module PowerShell manquant : $Name. Installe RSAT ou le module requis."
    }
    Import-Module $Name -ErrorAction Stop
}

function Ensure-OU {
    param([Parameter(Mandatory)][string]$DistinguishedName)

    if (Get-ADOrganizationalUnit -LDAPFilter "(distinguishedName=$DistinguishedName)" -ErrorAction SilentlyContinue) {
        return
    }

    # Création de la chaîne d'OU de gauche à droite.
    # Exemple : OU=T0,OU=Admins,DC=corp,DC=local
    $parts = $DistinguishedName -split ","
    $dcParts = $parts | Where-Object { $_ -like "DC=*" }
    $ouParts = $parts | Where-Object { $_ -like "OU=*" }

    [array]::Reverse($ouParts)

    $parent = ($dcParts -join ",")
    foreach ($ou in $ouParts) {
        $name = $ou -replace "^OU=", ""
        $currentDn = "OU=$name,$parent"
        if (-not (Get-ADOrganizationalUnit -LDAPFilter "(distinguishedName=$currentDn)" -ErrorAction SilentlyContinue)) {
            if ($PSCmdlet.ShouldProcess($currentDn, "Créer OU")) {
                New-ADOrganizationalUnit -Name $name -Path $parent -ProtectedFromAccidentalDeletion $true | Out-Null
            }
        }
        $parent = $currentDn
    }
}

function Ensure-ADGroup {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Path,
        [string]$Description = ""
    )

    Ensure-OU -DistinguishedName $Path

    $existing = Get-ADGroup -LDAPFilter "(sAMAccountName=$Name)" -ErrorAction SilentlyContinue
    if ($existing) { return $existing }

    if ($PSCmdlet.ShouldProcess($Name, "Créer groupe AD")) {
        New-ADGroup -Name $Name `
            -SamAccountName $Name `
            -GroupCategory Security `
            -GroupScope Global `
            -Path $Path `
            -Description $Description | Out-Null
    }

    return Get-ADGroup -LDAPFilter "(sAMAccountName=$Name)"
}

function New-RandomPassword {
    param([int]$Length = 22)

    $lower = "abcdefghjkmnpqrstuvwxyz"
    $upper = "ABCDEFGHJKMNPQRSTUVWXYZ"
    $digits = "23456789"
    $special = "!@#%*-_=+?"
    $all = ($lower + $upper + $digits + $special).ToCharArray()

    $chars = New-Object System.Collections.Generic.List[char]
    $chars.Add($lower[(Get-Random -Maximum $lower.Length)])
    $chars.Add($upper[(Get-Random -Maximum $upper.Length)])
    $chars.Add($digits[(Get-Random -Maximum $digits.Length)])
    $chars.Add($special[(Get-Random -Maximum $special.Length)])

    for ($i = $chars.Count; $i -lt $Length; $i++) {
        $chars.Add($all[(Get-Random -Maximum $all.Length)])
    }

    -join ($chars | Sort-Object { Get-Random })
}

function Ensure-AdminPasswordPolicy {
    param(
        [string[]]$AdminGroupNames,
        [string]$PolicyName = "PSO_Admin_Tiering_180J"
    )

    $pso = Get-ADFineGrainedPasswordPolicy -Filter "Name -eq '$PolicyName'" -ErrorAction SilentlyContinue
    if (-not $pso) {
        if ($PSCmdlet.ShouldProcess($PolicyName, "Créer PSO admin 180 jours")) {
            New-ADFineGrainedPasswordPolicy `
                -Name $PolicyName `
                -Precedence 10 `
                -ComplexityEnabled $true `
                -ReversibleEncryptionEnabled $false `
                -MinPasswordLength 14 `
                -PasswordHistoryCount 24 `
                -MaxPasswordAge (New-TimeSpan -Days 180) `
                -MinPasswordAge (New-TimeSpan -Days 1) `
                -LockoutThreshold 5 `
                -LockoutDuration (New-TimeSpan -Minutes 15) `
                -LockoutObservationWindow (New-TimeSpan -Minutes 15) | Out-Null
        }
    }

    foreach ($groupName in $AdminGroupNames) {
        $group = Get-ADGroup -Identity $groupName -ErrorAction SilentlyContinue
        if ($group) {
            try {
                if ($PSCmdlet.ShouldProcess($groupName, "Appliquer PSO admin 180 jours")) {
                    Add-ADFineGrainedPasswordPolicySubject -Identity $PolicyName -Subjects $groupName -ErrorAction Stop
                }
            }
            catch {
                if ($_.Exception.Message -notmatch "already") {
                    Write-Warning "Impossible d'appliquer la PSO à $groupName : $($_.Exception.Message)"
                }
            }
        }
    }
}

function Ensure-GpoSkeleton {
    param([array]$Servers)

    Ensure-Module -Name GroupPolicy

    $tiers = $Servers | Select-Object -ExpandProperty NiveauTiering -Unique
    foreach ($tier in $tiers) {
        $gpoName = "GPO_Tiering_${tier}_LocalAdmins"
        $gpo = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
        if (-not $gpo) {
            if ($PSCmdlet.ShouldProcess($gpoName, "Créer squelette GPO")) {
                New-GPO -Name $gpoName -Comment "Squelette GPO pour appliquer les groupes admin locaux du tier $tier. Configurer ensuite : Computer Configuration > Preferences > Control Panel Settings > Local Users and Groups." | Out-Null
            }
        }

        $targetOu = "OU=$tier,$ServerRootOU"
        Ensure-OU -DistinguishedName $targetOu

        try {
            if ($PSCmdlet.ShouldProcess($targetOu, "Lier $gpoName")) {
                New-GPLink -Name $gpoName -Target $targetOu -LinkEnabled Yes -ErrorAction Stop | Out-Null
            }
        }
        catch {
            if ($_.Exception.Message -notmatch "already|existe") {
                Write-Warning "Lien GPO non créé pour $targetOu : $($_.Exception.Message)"
            }
        }
    }
}

# Début
Ensure-Module -Name ActiveDirectory

if (-not (Test-Path $AccountsCsv)) { throw "Fichier introuvable : $AccountsCsv" }
if (-not (Test-Path $ServersCsv)) { throw "Fichier introuvable : $ServersCsv" }

New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null

Write-Step "Import des comptes et serveurs"
$accounts = Import-Csv -Path $AccountsCsv -Delimiter ";"
$servers = Import-Csv -Path $ServersCsv -Delimiter ";"

$passwordMap = @{}
if (Test-Path $PasswordCsv) {
    Import-Csv -Path $PasswordCsv -Delimiter ";" | ForEach-Object {
        $passwordMap[$_.sAMAccountName] = $_.InitialPassword
    }
}

Write-Step "Création des OU cibles"
$accounts | Select-Object -ExpandProperty "OU cible" -Unique | ForEach-Object {
    if (-not [string]::IsNullOrWhiteSpace($_)) {
        Ensure-OU -DistinguishedName $_
    }
}

foreach ($server in $servers) {
    if (-not [string]::IsNullOrWhiteSpace($server.OUCible)) {
        Ensure-OU -DistinguishedName $server.OUCible
    }
}

Write-Step "Création des groupes de Tiering"
Ensure-OU -DistinguishedName $GroupRootOU

$tierGroupNames = @()
$adminTierGroupNames = @()
foreach ($tier in @("T0","T1","T2")) {
    $tierAdminGroup = "GG_${tier}_Admins"
    $tierUserGroup  = "GG_${tier}_Users"
    $tierServerGroup = "GG_${tier}_Servers"

    Ensure-ADGroup -Name $tierAdminGroup -Path $GroupRootOU -Description "Comptes admin autorisés pour le tier $tier" | Out-Null
    Ensure-ADGroup -Name $tierUserGroup -Path $GroupRootOU -Description "Comptes utilisateurs rattachés au tier $tier" | Out-Null
    Ensure-ADGroup -Name $tierServerGroup -Path $GroupRootOU -Description "Serveurs rattachés au tier $tier" | Out-Null

    $tierGroupNames += $tierAdminGroup, $tierUserGroup, $tierServerGroup
    $adminTierGroupNames += $tierAdminGroup
}

Write-Step "Création des groupes d'administration par serveur"
$serverAccessMatrix = @()
foreach ($server in $servers) {
    $serverName = $server.NomServeur
    $tier = $server.NiveauTiering
    if ([string]::IsNullOrWhiteSpace($serverName) -or [string]::IsNullOrWhiteSpace($tier)) { continue }

    $localAdminGroup = "GLA_${serverName}_Administrators"
    Ensure-ADGroup -Name $localAdminGroup -Path $GroupRootOU -Description "Groupe à ajouter dans Administrators local sur $serverName" | Out-Null

    $tierAdminGroup = "GG_${tier}_Admins"

    if ($PSCmdlet.ShouldProcess("$tierAdminGroup -> $localAdminGroup", "Ajouter groupe tier dans groupe local admin serveur")) {
        Add-ADGroupMember -Identity $localAdminGroup -Members $tierAdminGroup -ErrorAction SilentlyContinue
    }

    $serverAccessMatrix += [pscustomobject]@{
        NomServeur = $serverName
        NiveauTiering = $tier
        GroupeAPlacerDansAdministratorsLocal = $localAdminGroup
        GroupeAdminAutorise = $tierAdminGroup
        OUCibleServeur = $server.OUCible
    }
}

Write-Step "Création / mise à jour des comptes"
$createdPasswords = @()

foreach ($account in $accounts) {
    $sam = $account.sAMAccountName
    $upn = $account."UPN / Email"
    $firstName = $account."Prénom"
    $lastName = $account.Nom
    $displayName = "$firstName $lastName"
    $tier = $account."Niveau Tiering"
    $ou = $account."OU cible"

    if ([string]::IsNullOrWhiteSpace($sam) -or [string]::IsNullOrWhiteSpace($ou)) {
        Write-Warning "Ligne ignorée car sAMAccountName ou OU cible vide."
        continue
    }

    $isAdmin = ($sam -like "adm-*") -or ($ou -like "*OU=Admins,*")
    $groupName = if ($isAdmin) { "GG_${tier}_Admins" } else { "GG_${tier}_Users" }

    $plainPassword = $passwordMap[$sam]
    if ([string]::IsNullOrWhiteSpace($plainPassword)) {
        $plainPassword = New-RandomPassword
    }

    $securePassword = ConvertTo-SecureString $plainPassword -AsPlainText -Force

    $existing = Get-ADUser -LDAPFilter "(sAMAccountName=$sam)" -ErrorAction SilentlyContinue
    if (-not $existing) {
        if ($PSCmdlet.ShouldProcess($sam, "Créer compte AD")) {
            New-ADUser `
                -Name $displayName `
                -GivenName $firstName `
                -Surname $lastName `
                -DisplayName $displayName `
                -SamAccountName $sam `
                -UserPrincipalName $upn `
                -EmailAddress $upn `
                -Path $ou `
                -AccountPassword $securePassword `
                -Enabled $true `
                -ChangePasswordAtLogon:(!$isAdmin) `
                -PasswordNeverExpires:$false `
                -Description "Compte $($account.Service) / $($account.Équipe) - Tiering $tier" | Out-Null
        }
    }
    else {
        Write-Host "Compte existant : $sam"
        if ($PSCmdlet.ShouldProcess($sam, "Mettre à jour attributs compte AD")) {
            Set-ADUser -Identity $sam `
                -DisplayName $displayName `
                -EmailAddress $upn `
                -UserPrincipalName $upn `
                -Description "Compte $($account.Service) / $($account.Équipe) - Tiering $tier"
        }
    }

    if ($PSCmdlet.ShouldProcess("$sam -> $groupName", "Ajouter compte au groupe de tier")) {
        Add-ADGroupMember -Identity $groupName -Members $sam -ErrorAction SilentlyContinue
    }

    $createdPasswords += [pscustomobject]@{
        sAMAccountName = $sam
        UPN = $upn
        DisplayName = $displayName
        NiveauTiering = $tier
        TypeCompte = if ($isAdmin) { "Admin" } else { "Standard" }
        InitialPassword = $plainPassword
        PasswordExpiresDays = if ($isAdmin) { 180 } else { "" }
        MustChangeAtNextLogon = if ($isAdmin) { $false } else { $true }
    }
}

Write-Step "Application de la politique mot de passe 180 jours aux groupes admin"
Ensure-AdminPasswordPolicy -AdminGroupNames $adminTierGroupNames

Write-Step "Export des résultats"
$createdPasswords | Export-Csv -Path (Join-Path $OutputFolder "MotsDePasse_Creation_Comptes.csv") -Delimiter ";" -NoTypeInformation -Encoding UTF8
$serverAccessMatrix | Export-Csv -Path (Join-Path $OutputFolder "Matrice_Acces_Serveurs.csv") -Delimiter ";" -NoTypeInformation -Encoding UTF8

if ($CreateGpoSkeleton) {
    Write-Step "Création des squelettes GPO"
    Ensure-GpoSkeleton -Servers $servers
}

Write-Host ""
Write-Host "Terminé." -ForegroundColor Green
Write-Host "Exports générés dans : $OutputFolder" -ForegroundColor Green
Write-Host ""
Write-Host "À faire côté GPO :" -ForegroundColor Yellow
Write-Host "1. Créer ou compléter les GPO GPO_Tiering_T0/T1/T2_LocalAdmins."
Write-Host "2. Aller dans Computer Configuration > Preferences > Control Panel Settings > Local Users and Groups."
Write-Host "3. Ajouter le groupe GLA_<Serveur>_Administrators dans le groupe local Administrators des serveurs concernés."
Write-Host "4. Filtrer chaque GPO sur l'OU serveurs du tier correspondant."
