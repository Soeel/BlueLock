# Package Tiering Model AD

Contenu :
- `Implement-TieringModelAD.ps1` : script PowerShell principal
- `Comptes_Tiering.csv` : export des comptes depuis le tableau Excel
- `Serveurs_Tiering.csv` : liste normalisée des serveurs par tier
- `MotsDePasse_Initiaux_DEMO.csv` : mots de passe initiaux générés pour la démonstration

Commande de test :
```powershell
.\Implement-TieringModelAD.ps1 -WhatIf
```

Commande réelle :
```powershell
.\Implement-TieringModelAD.ps1
```

Commande avec création des squelettes GPO :
```powershell
.\Implement-TieringModelAD.ps1 -CreateGpoSkeleton
```

Remarque importante :
La partie mail a été supprimée volontairement. Le script ne contient aucun envoi SMTP et n'envoie jamais de mot de passe par email. Pour le démonstrateur, les mots de passe initiaux sont exportés dans `exports/MotsDePasse_Creation_Comptes.csv`. En production, il faut privilégier un coffre-fort de mots de passe, PAM, CyberArk, KeePass entreprise, LAPS/Windows LAPS ou une remise via canal séparé.
