# Package Tiering AD avec detection automatique du domaine

Ce package contient un script PowerShell qui detecte automatiquement le domaine AD avec Get-ADDomain.

## Fichiers

- Implement-TieringModelAD.ps1
- Comptes_Admin_Tiering.csv
- Serveurs_Tiering.csv

## Test

```powershell
.\Implement-TieringModelAD.ps1 -WhatIf
```

## Execution reelle

```powershell
.\Implement-TieringModelAD.ps1
```

## Mettre a jour les CSV avec le domaine detecte

```powershell
.\Implement-TieringModelAD.ps1 -UpdateInputCsv
```

Cette option remplace automatiquement les UPN et OU dans les CSV avec le domaine detecte, par exemple blue.local et DC=blue,DC=local.
Une sauvegarde .bak est creee avant modification.

## Exports generes

- .\exports\MotsDePasse_Comptes_Admin.csv
- .\exports\Matrice_Acces_Serveurs.csv
- .\exports\Domaine_Detecte.csv

## Notes

Aucun mot de passe n'est envoye par mail.
Tous les comptes crees sont des comptes admin.
Les mots de passe contiennent uniquement lettres et chiffres.
