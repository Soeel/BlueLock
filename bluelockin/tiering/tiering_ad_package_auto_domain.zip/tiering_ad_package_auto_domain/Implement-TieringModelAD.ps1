<#
.SYNOPSIS
    Implementation simple d'un modele Tiering Active Directory avec detection automatique du domaine.

.DESCRIPTION
    - Detecte automatiquement le domaine AD avec Get-ADDomain.
    - Utilise automatiquement le DN du domaine, par exemple DC=blue,DC=local.
    - Cree les OU principales, les OU T0/T1/T2, les groupes, les comptes admin et les groupes d'acces serveur.
    - Tous les comptes crees sont des comptes admin.
    - Aucun envoi mail.
    - Les mots de passe sont generes par le script et exportes dans un CSV.
    - Les mots de passe contiennent uniquement lettres et chiffres.
    - Peut normaliser les fichiers CSV d'entree avec le domaine detecte.

.FICHIERS CSV ATTENDUS
    Comptes_Admin_Tiering.csv
    Serveurs_Tiering.csv

.EXEMPLES
    .\Implement-TieringModelAD.ps1 -WhatIf
    .\Implement-TieringModelAD.ps1
    .\Implement-TieringModelAD.ps1 -UpdateInputCsv
    .\Implement-TieringModelAD.ps1 -CreateGpoSkeleton
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$AccountsCsv = ".\Comptes_Admin_Tiering.csv",
    [string]$ServersCsv = ".\Serveurs_Tiering.csv",
    [string]$OutputFolder = ".\exports",

    [string]$AdminRootOuName = "Admins",
    [string]$GroupRootOuName = "Groups",
    [string]$ServerRootOuName = "Servers",

    [int]$PasswordLength = 20,
    [int]$AdminPasswordExpirationDays = 180,

    [switch]$UpdateInputCsv,
    [switch]$CreateGpoSkeleton
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "[+] $Message" -ForegroundColor Cyan
}

function Ensure-Module {
    param([Parameter(Mandatory = $true)][string]$Name)

    if (-not (Get-Module -ListAvailable -Name $Name)) {
        throw "Module PowerShell manquant: $Name"
    }

    Import-Module $Name -ErrorAction Stop
}

function Get-CsvValue {
    param(
        [Parameter(Mandatory = $true)]$Row,
        [Parameter(Mandatory = $true)][string[]]$Names
    )

    foreach ($name in $Names) {
        if ($Row.PSObject.Properties.Name -contains $name) {
            $value = $Row.PSObject.Properties[$name].Value
            if ($null -eq $value) { return "" }
            return ([string]$value).Trim()
        }
    }

    return ""
}

function Set-CsvValue {
    param(
        [Parameter(Mandatory = $true)]$Row,
        [Parameter(Mandatory = $true)][string]$Name,
        [AllowNull()][string]$Value
    )

    if ($Row.PSObject.Properties.Name -contains $Name) {
        $Row.$Name = $Value
    }
    else {
        $Row | Add-Member -NotePropertyName $Name -NotePropertyValue $Value
    }
}

function Remove-TextAccent {
    param([AllowNull()][string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ""
    }

    $normalized = $Text.Normalize([Text.NormalizationForm]::FormD)
    $builder = New-Object System.Text.StringBuilder

    foreach ($char in $normalized.ToCharArray()) {
        $category = [Globalization.CharUnicodeInfo]::GetUnicodeCategory($char)
        if ($category -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$builder.Append($char)
        }
    }

    return $builder.ToString().Normalize([Text.NormalizationForm]::FormC)
}

function ConvertTo-SafeName {
    param([AllowNull()][string]$Value)

    $valueNoAccent = Remove-TextAccent -Text $Value
    $safe = $valueNoAccent.ToUpper() -replace "[^A-Z0-9]", "_"
    $safe = $safe -replace "_+", "_"
    $safe = $safe.Trim("_")

    if ([string]::IsNullOrWhiteSpace($safe)) {
        return "UNKNOWN"
    }

    return $safe
}

function ConvertTo-SafeSamAccountName {
    param([AllowNull()][string]$Value)

    $valueNoAccent = Remove-TextAccent -Text $Value
    $safe = $valueNoAccent.ToLower() -replace "[^a-z0-9]", ""

    if ([string]::IsNullOrWhiteSpace($safe)) {
        return "admunknown"
    }

    if ($safe -notlike "adm*") {
        $safe = "adm$safe"
    }

    if ($safe.Length -gt 20) {
        $safe = $safe.Substring(0, 20)
    }

    return $safe
}

function Resolve-DomainInfo {
    $domain = Get-ADDomain -ErrorAction Stop

    return [pscustomobject]@{
        DnsRoot = $domain.DNSRoot
        DistinguishedName = $domain.DistinguishedName
        NetBIOSName = $domain.NetBIOSName
        AdminRootOU = "OU=$AdminRootOuName,$($domain.DistinguishedName)"
        GroupRootOU = "OU=$GroupRootOuName,$($domain.DistinguishedName)"
        ServerRootOU = "OU=$ServerRootOuName,$($domain.DistinguishedName)"
    }
}

function Convert-DomainDnFromDnsRoot {
    param([Parameter(Mandatory = $true)][string]$DnsRoot)

    $parts = $DnsRoot.Split(".") | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    return (($parts | ForEach-Object { "DC=$_" }) -join ",")
}

function Normalize-DistinguishedNameDomain {
    param(
        [AllowNull()][string]$Value,
        [Parameter(Mandatory = $true)][string]$DomainDN
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return ""
    }

    $clean = $Value.Trim()

    if ($clean -match "DC=") {
        $clean = $clean -replace "DC=[^,]+(,DC=[^,]+)*$", $DomainDN
    }

    return $clean
}

function Ensure-OU {
    param([Parameter(Mandatory = $true)][string]$DistinguishedName)

    try {
        Get-ADOrganizationalUnit -Identity $DistinguishedName -ErrorAction Stop | Out-Null
        return
    }
    catch {
        # OU missing, creation below
    }

    $parts = $DistinguishedName -split ","
    $dcParts = $parts | Where-Object { $_ -like "DC=*" }
    $ouParts = $parts | Where-Object { $_ -like "OU=*" }

    [array]::Reverse($ouParts)
    $parent = ($dcParts -join ",")

    foreach ($ouPart in $ouParts) {
        $ouName = $ouPart -replace "^OU=", ""
        $currentDn = "OU=$ouName,$parent"

        try {
            Get-ADOrganizationalUnit -Identity $currentDn -ErrorAction Stop | Out-Null
        }
        catch {
            if ($PSCmdlet.ShouldProcess($currentDn, "Create OU")) {
                New-ADOrganizationalUnit `
                    -Name $ouName `
                    -Path $parent `
                    -ProtectedFromAccidentalDeletion $false `
                    -ErrorAction Stop | Out-Null
            }
        }

        $parent = $currentDn
    }
}

function Ensure-ADGroup {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Path,
        [string]$Description = ""
    )

    Ensure-OU -DistinguishedName $Path

    $existingGroup = Get-ADGroup -LDAPFilter "(sAMAccountName=$Name)" -ErrorAction SilentlyContinue
    if ($existingGroup) {
        return $existingGroup
    }

    if ($PSCmdlet.ShouldProcess($Name, "Create AD group")) {
        New-ADGroup `
            -Name $Name `
            -SamAccountName $Name `
            -GroupCategory Security `
            -GroupScope Global `
            -Path $Path `
            -Description $Description `
            -ErrorAction Stop | Out-Null
    }

    return Get-ADGroup -LDAPFilter "(sAMAccountName=$Name)"
}

function New-RandomPassword {
    param([int]$Length = 20)

    if ($Length -lt 14) {
        $Length = 14
    }

    $lower = "abcdefghjkmnpqrstuvwxyz"
    $upper = "ABCDEFGHJKMNPQRSTUVWXYZ"
    $digits = "23456789"
    $allChars = ($lower + $upper + $digits).ToCharArray()

    $chars = New-Object System.Collections.Generic.List[char]
    $chars.Add($lower[(Get-Random -Maximum $lower.Length)])
    $chars.Add($upper[(Get-Random -Maximum $upper.Length)])
    $chars.Add($digits[(Get-Random -Maximum $digits.Length)])

    while ($chars.Count -lt $Length) {
        $chars.Add($allChars[(Get-Random -Maximum $allChars.Length)])
    }

    return (-join ($chars | Sort-Object { Get-Random }))
}

function Ensure-AdminPasswordPolicy {
    param(
        [string[]]$AdminGroupNames,
        [int]$ExpirationDays,
        [string]$PolicyName = "PSO_Admin_Tiering_180J"
    )

    $pso = Get-ADFineGrainedPasswordPolicy -Filter "Name -eq '$PolicyName'" -ErrorAction SilentlyContinue

    if (-not $pso) {
        if ($PSCmdlet.ShouldProcess($PolicyName, "Create password policy")) {
            New-ADFineGrainedPasswordPolicy `
                -Name $PolicyName `
                -Precedence 10 `
                -ComplexityEnabled $true `
                -ReversibleEncryptionEnabled $false `
                -MinPasswordLength 14 `
                -PasswordHistoryCount 24 `
                -MaxPasswordAge (New-TimeSpan -Days $ExpirationDays) `
                -MinPasswordAge (New-TimeSpan -Days 1) `
                -LockoutThreshold 5 `
                -LockoutDuration (New-TimeSpan -Minutes 15) `
                -LockoutObservationWindow (New-TimeSpan -Minutes 15) `
                -ErrorAction Stop | Out-Null
        }
    }

    foreach ($groupName in $AdminGroupNames) {
        $group = Get-ADGroup -Identity $groupName -ErrorAction SilentlyContinue

        if ($group) {
            try {
                if ($PSCmdlet.ShouldProcess($groupName, "Apply password policy")) {
                    Add-ADFineGrainedPasswordPolicySubject `
                        -Identity $PolicyName `
                        -Subjects $groupName `
                        -ErrorAction Stop
                }
            }
            catch {
                if ($_.Exception.Message -notmatch "already|existe|deja") {
                    Write-Warning "Impossible appliquer la PSO sur $groupName : $($_.Exception.Message)"
                }
            }
        }
    }
}

function Update-InputCsvFiles {
    param(
        [Parameter(Mandatory = $true)][array]$Accounts,
        [Parameter(Mandatory = $true)][array]$Servers,
        [Parameter(Mandatory = $true)][string]$AccountsPath,
        [Parameter(Mandatory = $true)][string]$ServersPath,
        [Parameter(Mandatory = $true)]$DomainInfo
    )

    $backupSuffix = ".bak_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

    Copy-Item -Path $AccountsPath -Destination "$AccountsPath$backupSuffix" -Force
    Copy-Item -Path $ServersPath -Destination "$ServersPath$backupSuffix" -Force

    foreach ($account in $Accounts) {
        $nom = Get-CsvValue -Row $account -Names @("Nom", "NOM")
        $prenom = Get-CsvValue -Row $account -Names @("Prenom", "FirstName")
        $rawSam = Get-CsvValue -Row $account -Names @("CompteAdmin", "sAMAccountName", "Login", "SamAccountName")
        $rawUpn = Get-CsvValue -Row $account -Names @("UPN", "UPN / Email", "Email", "Mail")
        $tier = Get-CsvValue -Row $account -Names @("NiveauTiering", "Niveau Tiering", "Tier")

        if ([string]::IsNullOrWhiteSpace($tier) -or $tier -notin @("T0", "T1", "T2")) {
            $tier = "T2"
        }

        if ([string]::IsNullOrWhiteSpace($rawSam)) {
            $baseSam = "$($prenom.Substring(0, [Math]::Min(1, $prenom.Length)))$nom"
            $sam = ConvertTo-SafeSamAccountName -Value $baseSam
        }
        else {
            $sam = ConvertTo-SafeSamAccountName -Value $rawSam
        }

        $upn = "$sam@$($DomainInfo.DnsRoot)"
        $ou = "OU=$tier,$($DomainInfo.AdminRootOU)"

        Set-CsvValue -Row $account -Name "CompteAdmin" -Value $sam
        Set-CsvValue -Row $account -Name "UPN" -Value $upn
        Set-CsvValue -Row $account -Name "NiveauTiering" -Value $tier
        Set-CsvValue -Row $account -Name "OUCible" -Value $ou
    }

    foreach ($server in $Servers) {
        $tier = Get-CsvValue -Row $server -Names @("NiveauTiering", "Niveau Tiering", "Tier")
        $serverOu = Get-CsvValue -Row $server -Names @("OUCible", "OU cible", "OU")

        if ([string]::IsNullOrWhiteSpace($tier) -or $tier -notin @("T0", "T1", "T2")) {
            $tier = "T2"
        }

        if ([string]::IsNullOrWhiteSpace($serverOu)) {
            $serverOu = "OU=$tier,$($DomainInfo.ServerRootOU)"
        }
        else {
            $serverOu = Normalize-DistinguishedNameDomain -Value $serverOu -DomainDN $DomainInfo.DistinguishedName
        }

        Set-CsvValue -Row $server -Name "NiveauTiering" -Value $tier
        Set-CsvValue -Row $server -Name "OUCible" -Value $serverOu
    }

    $Accounts | Export-Csv -Path $AccountsPath -Delimiter ";" -NoTypeInformation -Encoding UTF8
    $Servers | Export-Csv -Path $ServersPath -Delimiter ";" -NoTypeInformation -Encoding UTF8

    Write-Host "CSV mis a jour avec le domaine $($DomainInfo.DnsRoot). Backups crees avec suffixe $backupSuffix" -ForegroundColor Yellow
}

function Ensure-GpoSkeleton {
    param([Parameter(Mandatory = $true)]$DomainInfo)

    Ensure-Module -Name GroupPolicy

    foreach ($tier in @("T0", "T1", "T2")) {
        $gpoName = "GPO_Tiering_${tier}_LocalAdmins"
        $targetOu = "OU=$tier,$($DomainInfo.ServerRootOU)"

        Ensure-OU -DistinguishedName $targetOu

        $existingGpo = Get-GPO -Name $gpoName -ErrorAction SilentlyContinue
        if (-not $existingGpo) {
            if ($PSCmdlet.ShouldProcess($gpoName, "Create GPO")) {
                New-GPO `
                    -Name $gpoName `
                    -Comment "GPO skeleton for local admins on $tier servers" `
                    -ErrorAction Stop | Out-Null
            }
        }

        try {
            if ($PSCmdlet.ShouldProcess($targetOu, "Link GPO $gpoName")) {
                New-GPLink `
                    -Name $gpoName `
                    -Target $targetOu `
                    -LinkEnabled Yes `
                    -ErrorAction Stop | Out-Null
            }
        }
        catch {
            if ($_.Exception.Message -notmatch "already|existe|deja") {
                Write-Warning "Lien GPO non cree sur $targetOu : $($_.Exception.Message)"
            }
        }
    }
}

Ensure-Module -Name ActiveDirectory

Write-Step "Detection du domaine AD"
$DomainInfo = Resolve-DomainInfo

Write-Host "Domaine detecte : $($DomainInfo.DnsRoot)" -ForegroundColor Green
Write-Host "DN domaine       : $($DomainInfo.DistinguishedName)" -ForegroundColor Green
Write-Host "OU admins        : $($DomainInfo.AdminRootOU)" -ForegroundColor Green
Write-Host "OU groupes       : $($DomainInfo.GroupRootOU)" -ForegroundColor Green
Write-Host "OU serveurs      : $($DomainInfo.ServerRootOU)" -ForegroundColor Green

if (-not (Test-Path $AccountsCsv)) {
    throw "Fichier introuvable: $AccountsCsv"
}

if (-not (Test-Path $ServersCsv)) {
    throw "Fichier introuvable: $ServersCsv"
}

New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null

Write-Step "Import des fichiers CSV"
$accounts = Import-Csv -Path $AccountsCsv -Delimiter ";"
$servers = Import-Csv -Path $ServersCsv -Delimiter ";"

if ($UpdateInputCsv) {
    Write-Step "Mise a jour des CSV avec le domaine detecte"
    Update-InputCsvFiles `
        -Accounts $accounts `
        -Servers $servers `
        -AccountsPath $AccountsCsv `
        -ServersPath $ServersCsv `
        -DomainInfo $DomainInfo

    $accounts = Import-Csv -Path $AccountsCsv -Delimiter ";"
    $servers = Import-Csv -Path $ServersCsv -Delimiter ";"
}

Write-Step "Creation des OU principales"
Ensure-OU -DistinguishedName $DomainInfo.AdminRootOU
Ensure-OU -DistinguishedName $DomainInfo.GroupRootOU
Ensure-OU -DistinguishedName $DomainInfo.ServerRootOU

foreach ($tier in @("T0", "T1", "T2")) {
    Ensure-OU -DistinguishedName "OU=$tier,$($DomainInfo.AdminRootOU)"
    Ensure-OU -DistinguishedName "OU=$tier,$($DomainInfo.ServerRootOU)"
}

Write-Step "Creation des groupes admin par tier"
$adminTierGroupNames = @()

foreach ($tier in @("T0", "T1", "T2")) {
    $tierAdminGroup = "GG_${tier}_Admins"
    Ensure-ADGroup `
        -Name $tierAdminGroup `
        -Path $DomainInfo.GroupRootOU `
        -Description "Admin accounts for tier $tier" | Out-Null

    $adminTierGroupNames += $tierAdminGroup
}

Write-Step "Creation des groupes d'acces serveurs"
$serverAccessMatrix = @()

foreach ($server in $servers) {
    $serverName = Get-CsvValue -Row $server -Names @("NomServeur", "Nom serveur", "Serveur", "Server")
    $tier = Get-CsvValue -Row $server -Names @("NiveauTiering", "Niveau Tiering", "Tier")
    $serverRole = Get-CsvValue -Row $server -Names @("RoleServeur", "Role serveur", "Role")
    $serverOu = Get-CsvValue -Row $server -Names @("OUCible", "OU cible", "OU")

    if ([string]::IsNullOrWhiteSpace($serverName)) {
        continue
    }

    if ([string]::IsNullOrWhiteSpace($tier) -or $tier -notin @("T0", "T1", "T2")) {
        $tier = "T2"
    }

    if ([string]::IsNullOrWhiteSpace($serverOu)) {
        $serverOu = "OU=$tier,$($DomainInfo.ServerRootOU)"
    }
    else {
        $serverOu = Normalize-DistinguishedNameDomain -Value $serverOu -DomainDN $DomainInfo.DistinguishedName
    }

    Ensure-OU -DistinguishedName $serverOu

    $safeServerName = ConvertTo-SafeName -Value $serverName
    $localAdminGroup = "GLA_${safeServerName}_Administrators"
    $tierAdminGroup = "GG_${tier}_Admins"

    Ensure-ADGroup `
        -Name $localAdminGroup `
        -Path $DomainInfo.GroupRootOU `
        -Description "Local admin access group for server $serverName" | Out-Null

    if ($PSCmdlet.ShouldProcess("$tierAdminGroup to $localAdminGroup", "Add group member")) {
        Add-ADGroupMember `
            -Identity $localAdminGroup `
            -Members $tierAdminGroup `
            -ErrorAction SilentlyContinue
    }

    $serverAccessMatrix += [pscustomobject]@{
        NomServeur = $serverName
        NiveauTiering = $tier
        RoleServeur = $serverRole
        OUCibleServeur = $serverOu
        GroupeLocalAdminAD = $localAdminGroup
        GroupeAdminAutorise = $tierAdminGroup
    }
}

Write-Step "Creation des comptes admin"
$generatedPasswords = @()

foreach ($account in $accounts) {
    $nom = Get-CsvValue -Row $account -Names @("Nom", "NOM")
    $prenom = Get-CsvValue -Row $account -Names @("Prenom", "FirstName")
    $rawSam = Get-CsvValue -Row $account -Names @("CompteAdmin", "sAMAccountName", "Login", "SamAccountName")
    $tier = Get-CsvValue -Row $account -Names @("NiveauTiering", "Niveau Tiering", "Tier")
    $equipe = Get-CsvValue -Row $account -Names @("Equipe", "Team")
    $service = Get-CsvValue -Row $account -Names @("Service")
    $fonction = Get-CsvValue -Row $account -Names @("Fonction", "Poste")
    $manager = Get-CsvValue -Row $account -Names @("Manager")

    if ([string]::IsNullOrWhiteSpace($tier) -or $tier -notin @("T0", "T1", "T2")) {
        $tier = "T2"
    }

    if ([string]::IsNullOrWhiteSpace($rawSam)) {
        if ([string]::IsNullOrWhiteSpace($nom) -and [string]::IsNullOrWhiteSpace($prenom)) {
            Write-Warning "Ligne ignoree: nom et prenom vides"
            continue
        }

        $firstLetter = "x"
        if (-not [string]::IsNullOrWhiteSpace($prenom)) {
            $firstLetter = $prenom.Substring(0, [Math]::Min(1, $prenom.Length))
        }

        $baseSam = "$firstLetter$nom"
        $sam = ConvertTo-SafeSamAccountName -Value $baseSam
    }
    else {
        $sam = ConvertTo-SafeSamAccountName -Value $rawSam
    }

    if ([string]::IsNullOrWhiteSpace($sam)) {
        Write-Warning "Ligne ignoree: compte admin vide"
        continue
    }

    $upn = "$sam@$($DomainInfo.DnsRoot)"
    $displayName = "$prenom $nom".Trim()
    if ([string]::IsNullOrWhiteSpace($displayName)) {
        $displayName = $sam
    }

    $targetOu = "OU=$tier,$($DomainInfo.AdminRootOU)"
    $groupName = "GG_${tier}_Admins"

    $plainPassword = New-RandomPassword -Length $PasswordLength
    $securePassword = ConvertTo-SecureString $plainPassword -AsPlainText -Force

    $existingUser = Get-ADUser -LDAPFilter "(sAMAccountName=$sam)" -ErrorAction SilentlyContinue

    if (-not $existingUser) {
        if ($PSCmdlet.ShouldProcess($sam, "Create AD admin account")) {
            New-ADUser `
                -Name $displayName `
                -GivenName $prenom `
                -Surname $nom `
                -DisplayName $displayName `
                -SamAccountName $sam `
                -UserPrincipalName $upn `
                -EmailAddress $upn `
                -Path $targetOu `
                -AccountPassword $securePassword `
                -Enabled $true `
                -ChangePasswordAtLogon $false `
                -PasswordNeverExpires $false `
                -Description "Admin account tier $tier" `
                -ErrorAction Stop | Out-Null
        }
    }
    else {
        Write-Host "Compte existant: $sam" -ForegroundColor Yellow

        if ($PSCmdlet.ShouldProcess($sam, "Update AD admin account")) {
            Set-ADUser `
                -Identity $sam `
                -DisplayName $displayName `
                -EmailAddress $upn `
                -UserPrincipalName $upn `
                -Description "Admin account tier $tier" `
                -ErrorAction Stop
        }
    }

    if ($PSCmdlet.ShouldProcess("$sam to $groupName", "Add admin account to tier group")) {
        Add-ADGroupMember `
            -Identity $groupName `
            -Members $sam `
            -ErrorAction SilentlyContinue
    }

    $generatedPasswords += [pscustomobject]@{
        CompteAdmin = $sam
        UPN = $upn
        Nom = $nom
        Prenom = $prenom
        DisplayName = $displayName
        Equipe = $equipe
        Service = $service
        Fonction = $fonction
        Manager = $manager
        NiveauTiering = $tier
        MotDePasseInitial = $plainPassword
        ExpirationMotDePasseJours = $AdminPasswordExpirationDays
    }
}

Write-Step "Application de la politique mot de passe admin"
Ensure-AdminPasswordPolicy -AdminGroupNames $adminTierGroupNames -ExpirationDays $AdminPasswordExpirationDays

Write-Step "Export des resultats"
$passwordFile = Join-Path $OutputFolder "MotsDePasse_Comptes_Admin.csv"
$matrixFile = Join-Path $OutputFolder "Matrice_Acces_Serveurs.csv"
$domainFile = Join-Path $OutputFolder "Domaine_Detecte.csv"

$generatedPasswords | Export-Csv -Path $passwordFile -Delimiter ";" -NoTypeInformation -Encoding UTF8
$serverAccessMatrix | Export-Csv -Path $matrixFile -Delimiter ";" -NoTypeInformation -Encoding UTF8
$DomainInfo | Export-Csv -Path $domainFile -Delimiter ";" -NoTypeInformation -Encoding UTF8

if ($CreateGpoSkeleton) {
    Write-Step "Creation des squelettes GPO"
    Ensure-GpoSkeleton -DomainInfo $DomainInfo
}

Write-Host ""
Write-Host "Termine." -ForegroundColor Green
Write-Host "Domaine utilise: $($DomainInfo.DnsRoot)" -ForegroundColor Green
Write-Host "Dossier export: $OutputFolder" -ForegroundColor Green
Write-Host "Fichier mots de passe: $passwordFile" -ForegroundColor Yellow
Write-Host "Fichier matrice serveurs: $matrixFile" -ForegroundColor Yellow
Write-Host "Fichier domaine detecte: $domainFile" -ForegroundColor Yellow
Write-Host ""
Write-Host "Action GPO restante:" -ForegroundColor Yellow
Write-Host "Ajouter les groupes GLA_<SERVEUR>_Administrators dans le groupe Administrators local des serveurs concernes."
